import React from 'react'
import { useSelector,useDispatch } from 'react-redux'
import AddEditContacts2 from './components/contact/AddEditContacts2'
import Contact1 from './components/contact/Contact1'
import { showOrHide1 } from './store/contact/Actions'
const App = () => {
  let showOrHide=useSelector((state)=>state.showOrHide)
  // console.log('showOrHide',showOrHide)
  const dispatch=useDispatch()

  const addHandler=(r)=>{
    showOrHide=r
    console.log('show',showOrHide)
    dispatch(showOrHide1(r))
    
  }
  return (
    <div>
      <button onClick={()=>addHandler(1)}>add</button>
      <Contact1 />
      <br />
      <hr />
    <AddEditContacts2 />
    </div>
  )
}

export default App
