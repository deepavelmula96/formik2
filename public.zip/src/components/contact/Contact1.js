import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { deleteContact, getSingleContact } from '../../store/contact/Actions'
// import AddEditContacts2 from './AddEditContacts2'

const Contact1 = () => {
    const contacts=useSelector(state=>state.contacts)
    const dispatch=useDispatch()
    console.log('Contact')
    return (
        <div>
            <div>
                <h1>All Contacts</h1>
            </div>
            <div>
                {/* {contacts.length === 0 && <p>no contact found</p>   } */}
                {contacts.length>1 && (
                    <table>
                        <thead>
                            <tr>
                                <th>EnglishName</th>
                                <th>ArabicName</th>
                                <th>Prefix</th>
                                <th>Location</th>
                                <th>actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {contacts.map((item,index)=>(
                                <tr key={index}>
                                    <td>{item.englishName}</td>
                                    <td>{item.arabicName}</td>
                                    <td>{item.prefix}</td>
                                    <td>{item.location}</td>
                                    <td>
                                        { index>0 && <div>
                                            <button onClick={()=>dispatch(getSingleContact(1,index))} >edit</button>
                                        <button onClick={()=>dispatch(deleteContact(index))}>delete</button>
                                        </div> 
                                        
                                        }
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
            <div>
             {/* <AddEditContacts2 newData={contact}/> */}
            </div>
        </div>
    )
}

export default Contact1
