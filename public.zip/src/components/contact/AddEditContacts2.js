import { ErrorMessage, Field, Formik, Form } from 'formik'
import React from 'react'
import { useDispatch } from 'react-redux'
import { addContact, editContact, getAllContact, showOrHide1 } from '../../store/contact/Actions'
import { useSelector } from 'react-redux'

import * as Yup from 'yup'
const AddEditContacts2 = () => {
  let showOrHide=useSelector((state)=>state.showOrHide)

    console.log('addedit',showOrHide)
    const editData = useSelector(state => state.contact)
    const initialValues = {
        englishName: editData?.englishName || '',
        arabicName: editData?.arabicName || "",
        prefix:editData?.prefix||'',
        location:editData?.location||'',
        countries:''
    }
    const validate = Yup.object().shape({
        englishName: Yup.string().min(3).max(5).required()
    })
    const dispatch = useDispatch()
    const handleSubmit = (e, { resetForm }) => {
        if (editData.id !== null && editData.id !== undefined) {
            dispatch(editContact(e, editData.id))
            editData.id = null
            editData.englishName=''
            editData.arabicName=''
            editData.prefix='';
            editData.location=''

            dispatch(showOrHide1(false))
        }
        else {
            dispatch(addContact(e))
            dispatch(showOrHide1(false))
        }
        resetForm();
    }
 
    return (
        <div>
            { showOrHide&&  <Formik initialValues={initialValues} onSubmit={handleSubmit}
                enableReinitialize
                validationSchema={validate} >
               { ({setFieldValue})=>
               <Form>
                    <div>
                        <label>EnglishName</label> <br />
                        <Field name='englishName' />
                        <ErrorMessage name='englishName' />
                    </div>
                    <div>
                        <label>ArabicName</label> <br />
                        <Field name='arabicName' />
                        <ErrorMessage name='arabicName' />
                    </div>
                    <div>
                        <label>Prefix</label> <br />
                        <Field name='prefix' />
                        <ErrorMessage name='prefix' />
                    </div>
                    <div>
                        <label>Location</label> <br />
                        <Field name='location' />
                        <ErrorMessage name='location' />
                    </div>
               
                    <button type='submit'>submit </button>
                    <button type='reset'>cancel</button>
                </Form>}
            </Formik>}
        </div>
    )
}

export default AddEditContacts2