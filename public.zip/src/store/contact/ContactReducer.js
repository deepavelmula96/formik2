import { ADD_CONTACT, DELETE_CONTACT, EDIT_CONTACT, GET_ALL_CONTACTS, GET_SINGLE_CONTACT, SHOW_OR_HIDE } from './ActionTypes'

const initialState={
    contacts:[{
        englishName:'',
        arabicName:'',
        prefix:'',
        location:''
    }],
    contact:{
    },
    showOrHide:false
}
export const ContactReducer=(state=initialState,action)=>{
    switch(action.type){
        case GET_ALL_CONTACTS:{
            return{...state}
        }
        case SHOW_OR_HIDE:{
            return{...state,showOrHide:action.e}
        }
        case DELETE_CONTACT:{
            let contacts1=[...state.contacts];
            contacts1.splice(action.id,1);
            return{...state,contacts:contacts1}
        }
        case ADD_CONTACT:{
            let contacts2=[...state.contacts];
            contacts2.push(action.payload);
            
            return{...state, contacts:contacts2}
        }
        case GET_SINGLE_CONTACT:{
            //  getting only single index
            console.log('singleunde',action.payload)
            return{...state,
                   contact:{...state.contacts[action.index],
                              id:action.index},showOrHide:action.payload}
        }
        case EDIT_CONTACT:{
            let contacts=[...state.contacts]
            contacts[action.id]=action.payload
            return{...state,contacts}
        }
        default:
            return state;
    }
}
export default ContactReducer