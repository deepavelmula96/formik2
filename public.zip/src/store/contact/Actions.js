import { ADD_CONTACT, DELETE_CONTACT, EDIT_CONTACT, GET_ALL_CONTACTS, GET_SINGLE_CONTACT, SHOW_OR_HIDE } from "./ActionTypes"

export const getAllContact=()=>{
    return{
        type:GET_ALL_CONTACTS
    }
}
export const showOrHide1=(e)=>({
    type:SHOW_OR_HIDE,
    e
})

export const addContact=(contact)=>{
    return{
        type:ADD_CONTACT,
        payload:contact
    }
}
export const  deleteContact=(id)=>{
    return{
        type:DELETE_CONTACT,
        id
    }
}
export const getSingleContact=(e,index)=>{
    console.log('singledddddd',e)
    return{
        type:GET_SINGLE_CONTACT,
        payload:e,
        index
    }
}
export const editContact=(contact, id)=>{
    return{
        type:EDIT_CONTACT,
        payload:contact,id
    }
}
