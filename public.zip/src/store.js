import { createStore } from "redux";
// import { sample2Reducer } from "./component/redux/all/sample2/reducer";
import {ContactReducer} from './store/contact/ContactReducer'
 const store=createStore(ContactReducer)
 export default store





















// import {createStore,combineReducers, applyMiddleware } from 'redux';
// // import user_reducer from './reducers/user_reducer';
// import createSagaMiddleware from 'redux-saga';
// import userSaga from './sagas/userSaga';
// import user_reducer from './component/redux/reducer.js/user_reducer';
// import Reducercontact1 from './component/contact1/Reducercontact1';
// import { watchContact } from './component/contact1/SagaContact1';

// const sagaMiddleware = createSagaMiddleware();

// const rootReducer=combineReducers({
//   // user:user_reducer,
//   contact:Reducercontact1
  
  
  
// })
// const store =  createStore(Reducercontact1,
//   // rootReducer, 
//                 applyMiddleware(sagaMiddleware));
// // sagaMiddleware.run(userSaga);
// sagaMiddleware.run(watchContact);
// console.log("store",store)
// store.subscribe(()=>{
//   console.log("latest state value :: ",store.getState() );
  
// });
 

// export default store;




// // import createSagaMiddleware from "@redux-saga/core";
// // import { applyMiddleware, createStore } from "redux";
// // import ageReducer from "./component/redux/reducer.js/ageReducer";
// // import { watchAgeUp } from "./sagas/saga";

// // const sagaMiddleware=createSagaMiddleware();
// // export const store=createStore(ageReducer,applyMiddleware(sagaMiddleware))
// // sagaMiddleware.run(watchAgeUp)
